# Enter html directory
cd /home/stage-Rigidas/rigidasapi/

npm i

# Copy configuration from /var/www/api, see README.MD for more information

cp -r /home/datacredentials/api /home/stage-Rigidas/rigidasapi/node_modules/api
cp -r /home/datacredentials/api-validator /home/stage-Rigidas/rigidasapi/node_modules/api-validator
cp -r /home/datacredentials/database.js /home/stage-Rigidas/rigidasapi/node_modules/database.jsi


# start pm2 

pm2 restart all
